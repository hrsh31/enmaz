# Alarm Clock
A simple and elegant alarm clock app in flutter.
#
Enmaz Internship Project!!! [Batch-21]
#
Install all the packages in VS code and run the below command while connected to a phone having usb debbuging on flutter run
